/*
 * dynamic_allocator.c
 *
 *  Created on: Sep 21, 2023
 *      Author: HP
 */
#include <inc/assert.h>
#include <inc/string.h>
#include "../inc/dynamic_allocator.h"
#include <inc/memlayout.h>




//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//
//==================================
// [1] GET PAGE VA:
//==================================
__inline__ uint32 to_page_va(struct PageInfoElement *ptrPageInfo)
{
	//Get start VA of the page from the corresponding Page Info pointer
	int idxInPageInfoArr = (ptrPageInfo - pageBlockInfoArr);
	return dynAllocStart + (idxInPageInfoArr << PGSHIFT);
}

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

//==================================
// [1] INITIALIZE DYNAMIC ALLOCATOR:
//==================================
bool is_initialized = 0;
void initialize_dynamic_allocator(uint32 daStart, uint32 daEnd)
{
    //==================================================================================
    //DON'T CHANGE THESE LINES==========================================================
    //==================================================================================
    {
        assert(daEnd <= daStart + DYN_ALLOC_MAX_SIZE);
        is_initialized = 1;
    }
    //==================================================================================
    //==================================================================================
    //TODO: [PROJECT'25.GM#1] DYNAMIC ALLOCATOR - #1 initialize_dynamic_allocator
    //Your code is here
    dynAllocStart = daStart;
    dynAllocEnd = daEnd;

    //initialize freepage list
    LIST_INIT(&freePagesList);

    // initialize pageInfoArr
    for(int i = 0; i < (daEnd - daStart)/PAGE_SIZE; i++) {
        pageBlockInfoArr[i].block_size = 0;
        pageBlockInfoArr[i].num_of_free_blocks = 0;
        pageBlockInfoArr[i].prev_next_info.le_next = NULL;
        pageBlockInfoArr[i].prev_next_info.le_prev = NULL;

        LIST_INSERT_TAIL(&freePagesList, &pageBlockInfoArr[i]);
    }

    for(int i = 0; i < LOG2_MAX_SIZE - LOG2_MIN_SIZE + 1; i++) {
        LIST_INIT(&freeBlockLists[i]);
    }

    //Comment the following line
    // panic("initialize_dynamic_allocator() Not implemented yet");

}

//===========================
// [2] GET BLOCK SIZE:
//===========================
inline uint32 get_block_size(void *va)
{
    //TODO: [PROJECT'25.GM#1] DYNAMIC ALLOCATOR - #2 get_block_size
    //Your code is here

    if ((uint32)va < dynAllocStart || (uint32)va >= dynAllocEnd) {
        return 0;
    }

    uint32 index = ((uint32)va - dynAllocStart) / PAGE_SIZE;
    return pageBlockInfoArr[index].block_size;

    //Comment the following line
    // panic("get_block_size() Not implemented yet");
}
//===========================
// 3) ALLOCATE BLOCK:
//===========================
int num=0;
void *alloc_block(uint32 size)
{
	//==================================================================================
	//DON'T CHANGE THESE LINES==========================================================
	//==================================================================================
	{
		assert(size <= DYN_ALLOC_MAX_BLOCK_SIZE);
	}
	//==================================================================================
	//==================================================================================
	//TODO: [PROJECT'25.GM#1] DYNAMIC ALLOCATOR - #3 alloc_block

	//Get Nearest Power of 2 Larger than given size
	int blockSizeNeeded;
	int ind;
	if (size <= 8){
	    blockSizeNeeded = DYN_ALLOC_MIN_BLOCK_SIZE;
	    ind = 0;
	}
	else{
	    int n = 8;
		for (ind = 0; ind < 9; ind++){
			if (n >= size && n <= 2048){
				blockSizeNeeded = n;
				break;
			}
			else {
				n *= 2;
			}
		}

	}

	//Calculate the list index
	//int listIndex = 0;
	//	{
	//		uint32 tmp = DYN_ALLOC_MIN_BLOCK_SIZE;
	//		while (tmp < blockSizeNeeded) {
	//			tmp *= 2;
	//			listIndex++;
	//		}
	//	}

	struct BlockElement *blk = LIST_FIRST(&freeBlockLists[ind]);

	//case1 ---> if a free block exists
	if (blk != NULL){
		LIST_REMOVE(&freeBlockLists[ind], blk);

		uint32 blk_va = (uint32)blk;
		uint32 page_index = ((blk_va - dynAllocStart) / PAGE_SIZE);
		uint32 page_start = dynAllocStart + (page_index * PAGE_SIZE);

		struct PageInfoElement *pageInfo = &pageBlockInfoArr[page_index];

		pageInfo->num_of_free_blocks--;
		return (void*)blk_va;
	}

	//case2 ---> if no free block of needed size BUT a free page exists
	else {

		// Check if there is a completely free page available
	  struct PageInfoElement *pageInfo = LIST_FIRST(&freePagesList);
	 if (pageInfo != NULL)
	  {
	     LIST_REMOVE(&freePagesList, pageInfo);

	     // Get the virtual address of the page
	     uint32 pageVA = to_page_va(pageInfo);

	     // Physically allocate the page from kernel allocator
	     int ret = get_page((void*)pageVA);
	     if (ret!=0){
	    	 return NULL;
	     }


	     // Slice the page into blocks of size "blockSizeNeeded"
	     uint32 blocksPerPage = PAGE_SIZE / blockSizeNeeded;
	     // Set metadata for this page
	     pageInfo->block_size = blockSizeNeeded;
	     pageInfo->num_of_free_blocks = blocksPerPage;

	     // Insert all blocks into the corresponding free-block list
	     for (int i = 0; i < blocksPerPage; i++) {
	         struct BlockElement *blk = (struct BlockElement*)(pageVA + (i * blockSizeNeeded));
	         LIST_INSERT_HEAD(&freeBlockLists[ind], blk);
	     }

	     //allocate one block:
	     struct BlockElement *allocated = LIST_FIRST(&freeBlockLists[ind]);
	     LIST_REMOVE(&freeBlockLists[ind], allocated);
	     pageInfo->num_of_free_blocks--;

	     return (void*)allocated;
	 }
	 //Case 3 ---> if no free blocks of the requested size and no free pages, scan larger sizes
	 else if (pageInfo == NULL) {
		 int j;
		 	 for (j = ind; j < (LOG2_MAX_SIZE - LOG2_MIN_SIZE); j++) {
		 	     struct BlockElement *larger_blk = LIST_FIRST(&freeBlockLists[j]);
		 	     if (larger_blk != NULL) {

		 	         //if we find a larger block allocate it
		 	         LIST_REMOVE(&freeBlockLists[j], larger_blk);

		 	         uint32 blk_va = (uint32)larger_blk;
		 	         uint32 page_index = ((blk_va - dynAllocStart) / PAGE_SIZE);
		 	         uint32 page_start = dynAllocStart + (page_index * PAGE_SIZE);


		 	         struct PageInfoElement *pageInfo = &pageBlockInfoArr[page_index];

		 	         pageInfo->num_of_free_blocks--;
		 	         return (void *)larger_blk;
		 	     	 }
		 	 	 }

	 }
	 else {
		 return NULL;
	 }
	}
	//CASE 4 ----> Still nothing
	//panic("alloc_block(): no blocks available (no free memory)");
	return NULL;

}

//===========================
// [4] FREE BLOCK:
//===========================
void free_block(void *va)
{
	//==================================================================================
	//DON'T CHANGE THESE LINES==========================================================
	//==================================================================================
	{
		assert((uint32)va >= dynAllocStart && (uint32)va < dynAllocEnd);
	}
	//==================================================================================
	//==================================================================================
	//TODO: [PROJECT'25.GM#1] DYNAMIC ALLOCATOR - #4 free_block
		//Your code is here
		//Comment the following line
	va=(void*)ROUNDDOWN((uint32)va, PAGE_SIZE);

		uint32 pageNum = ((uint32)va - dynAllocStart) / PAGE_SIZE;

		struct PageInfoElement* PageInfo;
		PageInfo = &pageBlockInfoArr[pageNum];  // PageInfoElement -> struct bta3t el page feha info (size of blocks and free blocks)
		                                        // PageBlockInfoArr -> array of structs btb2a feha (PageInfoElement)s

		uint32 block_size = PageInfo->block_size;


		int list_num = 0;
		for (int i = LOG2_MIN_SIZE; i < LOG2_MAX_SIZE; i++) {   // el list mn zero or one
			if ((1 << i) == block_size) {
				list_num = i - LOG2_MIN_SIZE;
				break;
			}
		}
		struct BlockElement* FreeBlock;
		FreeBlock = (struct BlockElement*)va;
		PageInfo->num_of_free_blocks++;
		LIST_INSERT_HEAD(&freeBlockLists[list_num],FreeBlock);
		if (PageInfo->num_of_free_blocks==(PAGE_SIZE/PageInfo->block_size)){

			uint32 pageStartAddr = dynAllocStart + pageNum * PAGE_SIZE;
			uint32 pageEndAddr = pageStartAddr + PAGE_SIZE;
			struct BlockElement * blk=NULL;
			LIST_FOREACH(blk, &freeBlockLists[list_num]) {
				if ((uint32)blk>=pageStartAddr  &&(uint32)blk<=pageEndAddr){
					LIST_REMOVE(&freeBlockLists[list_num],blk);
				}
			}
			PageInfo->block_size=0;
			PageInfo->num_of_free_blocks=0;
			LIST_INSERT_HEAD(&freePagesList,PageInfo);

			return_page((void*)pageStartAddr);

		}

	}

//==================================================================================//
//============================== BONUS FUNCTIONS ===================================//
//==================================================================================//

//===========================
// [1] REALLOCATE BLOCK:
//===========================
void *realloc_block(void* va, uint32 new_size)
{
	//TODO: [PROJECT'25.BONUS#2] KERNEL REALLOC - realloc_block
	//Your code is here
	//Comment the following line
	panic("realloc_block() Not implemented yet");
}
