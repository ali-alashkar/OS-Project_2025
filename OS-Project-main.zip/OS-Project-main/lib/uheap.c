#include <inc/lib.h>
#include<inc/uheap.h>
//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//
struct heapPages heapPages;
void insert_sorted_page(struct uheapPage *Page) {
    struct uheapPage *pag;
    LIST_FOREACH(pag, &heapPages) {
        if ((uint32)Page->va < (uint32)pag->va) {
            LIST_INSERT_BEFORE(&heapPages,pag, Page);
            return;
        }
    }
    LIST_INSERT_TAIL(&heapPages, Page);
}
//==============================================
// [1] INITIALIZE USER HEAP:
//==============================================
int __firstTimeFlag = 1;
struct heapBlocks heapBlocks;
struct uspinlock uheap_lock;
LIST_HEAD(heapBlocks, uHeapBlock) heapBlocks;
void uheap_init()
{
	if(__firstTimeFlag)
	{
		initialize_dynamic_allocator(USER_HEAP_START, USER_HEAP_START + DYN_ALLOC_MAX_SIZE);
		uheapPlaceStrategy = sys_get_uheap_strategy();
		uheapPageAllocStart = dynAllocEnd + PAGE_SIZE;
		uheapPageAllocBreak = uheapPageAllocStart;

		__firstTimeFlag = 0;
	}
	LIST_INIT(&heapBlocks);
	init_uspinlock(&uheap_lock, "uheap", 1);
}

//==============================================
// [2] GET A PAGE FROM THE KERNEL FOR DA:
//==============================================
int get_page(void* va)
{
	int ret = __sys_allocate_page(ROUNDDOWN(va, PAGE_SIZE), PERM_USER|PERM_WRITEABLE|PERM_UHPAGE);
	if (ret < 0)
		panic("get_page() in user: failed to allocate page from the kernel");
	return 0;
}

//==============================================
// [3] RETURN A PAGE FROM THE DA TO KERNEL:
//==============================================
void return_page(void* va)
{
	int ret = __sys_unmap_frame(ROUNDDOWN((uint32)va, PAGE_SIZE));
	if (ret < 0)
		panic("return_page() in user: failed to return a page to the kernel");
}

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//

//=================================
// [1] ALLOCATE SPACE IN USER HEAP:
//=================================

void* malloc(uint32 size)
{
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	uheap_init();
	if (size == 0) return NULL ;
	//==============================================================
	//TODO: [PROJECT'25.IM#2] USER HEAP - #1 malloc
		if (size <= DYN_ALLOC_MAX_BLOCK_SIZE) {
			return alloc_block(size);
		}

		uint32 pageNum = (size + PAGE_SIZE - 1) / PAGE_SIZE;
		uint32 ActualSize = pageNum * PAGE_SIZE;
		void* myVa = NULL;
		bool worstfound = 0;
		bool breakf=0;
		bool exactf=0;
		struct uheapPage *Page=NULL;
		struct uheapPage *tempPage = NULL;
		struct uheapPage *newPage = NULL;
		struct uheapPage *pagg = NULL;
		uint32 max = 0;

		LIST_FOREACH(Page, &heapPages) {//exact
			if (Page->free && Page->size == ActualSize) {
				myVa = Page->va;
				Page->free=0;
				exactf=1;
				break;
			}
		}
		if (myVa==NULL){//worst
		LIST_FOREACH(Page, &heapPages) {
			if (Page->free && Page->size > ActualSize && Page->size > max) {
				max = Page->size;
				tempPage = Page;
				myVa = Page->va;
				worstfound = 1;
			}
		}
		if (!worstfound ) {//update break
				uint32 remSize = USER_HEAP_MAX - uheapPageAllocBreak;
				if (remSize < ActualSize) {
					return NULL;
				}
				myVa = (void*)uheapPageAllocBreak;
				breakf=1;
			}
		}
		sys_allocate_user_mem((uint32)myVa, ActualSize);
		if(exactf)
			Page->free=0;
		else if (worstfound ) {
			newPage = alloc_block(sizeof(struct uheapPage));
			if (!newPage) {
			                return NULL;
			            }
			newPage->va = tempPage->va;
			newPage->size = ActualSize;
			newPage->free = 0;

			tempPage->va += ActualSize;
			tempPage->size -= ActualSize;
			tempPage->free = 1;
			insert_sorted_page(newPage);
			myVa = newPage->va;
		} else if (breakf) {
			pagg = alloc_block(sizeof(struct uheapPage));
			if (!pagg) {
			                return NULL;
			            }
			pagg->free = 0;
			pagg->size = ActualSize;
			pagg->va = myVa;
			insert_sorted_page(pagg);
			uheapPageAllocBreak = ROUNDUP(uheapPageAllocBreak, PAGE_SIZE);
			uheapPageAllocBreak =(uint32)myVa+ ActualSize;
		}
		return myVa;
}

//=================================
// [2] FREE SPACE FROM USER HEAP:
//=================================
void free(void* virtual_address)
{
	//TODO: [PROJECT'25.IM#2] USER HEAP - #3 free
	//Your code is here
	uheap_init();
	virtual_address=(void*)ROUNDDOWN((uint32)virtual_address, PAGE_SIZE);

	if (virtual_address == NULL ){
	return;
	}

	if((uint32)virtual_address>=USER_HEAP_MAX &&(uint32)virtual_address<dynAllocEnd){
			free_block(virtual_address);
			return;
		}
	if ((uint32)virtual_address < USER_HEAP_START ||(uint32)virtual_address >= USER_HEAP_MAX)
	{
		return;
	}

	struct uheapPage* Page = NULL;
	LIST_FOREACH(Page, &heapPages)
	{
		if (Page->va == virtual_address)
			break;
	}

	if (Page == NULL)
	{
		return;
	}

    uint32 size=Page->size;
	sys_free_user_mem((uint32)virtual_address, size);

	Page->free = 1;
	struct uheapPage* prev = Page->prev_next_info.le_prev;
	        struct uheapPage* next = Page->prev_next_info.le_next;
	        struct uheapPage* tmp=Page;
	        //merge
	        if (next!=NULL &&next->free){
	            Page->size+=next->size;
	            LIST_REMOVE(&heapPages,next);
	        }
	        if (prev!=NULL &&prev->free){
	            prev->size+=Page->size;
	            LIST_REMOVE(&heapPages,Page);
	            tmp=prev;
	        }


	        if ((uint32)(tmp->va+tmp->size)==uheapPageAllocBreak){
	                    uheapPageAllocBreak-=tmp->size;
	                    LIST_REMOVE(&heapPages,tmp);
	                }

	return;



	//Comment the following line
	//panic("free() is not implemented yet...!!");
}

//=================================
// [3] ALLOCATE SHARED VARIABLE:
//=================================
void insert_sorted_block(struct uHeapBlock *blk) {
    struct uHeapBlock *b;
    LIST_FOREACH(b, &heapBlocks) {
        if ((uint32)blk->va < (uint32)b->va) {
            LIST_INSERT_BEFORE(&heapBlocks,b, blk);
            return;
        }
    }
    LIST_INSERT_TAIL(&heapBlocks, blk);
}
void* smalloc(char *sharedVarName, uint32 size, uint8 isWritable)
{
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	uheap_init();
	if (size == 0) return NULL ;
	acquire_uspinlock(&uheap_lock);

		uint32 pageNum = (size + PAGE_SIZE - 1) / PAGE_SIZE;
		uint32 ActualSize = pageNum * PAGE_SIZE;

		void* myVa = NULL;
		bool worstfound = 0;
		bool breakf=0;
		bool exactf=0;
		struct uheapPage *blk=NULL;
		struct uheapPage *TemPblk = NULL;
		struct uheapPage *newBlk = NULL;
		struct uheapPage *blkk = NULL;
		uint32 max = 0;

		LIST_FOREACH(blk, &heapPages) {//exact
			if (blk->free && blk->size == ActualSize) {
				myVa = blk->va;
				blk->free=0;
				exactf=1;
				break;
			}
		}
		if (myVa==NULL){//worst
			LIST_FOREACH(blk, &heapPages) {
				if (blk->free && blk->size > ActualSize && blk->size > max) {
					max = blk->size;
					TemPblk = blk;
					myVa = blk->va;
					worstfound = 1;
				}
		}

		if (!worstfound) {//update break
				uint32 remSize = USER_HEAP_MAX - uheapPageAllocBreak;
				if (remSize < ActualSize) {
					release_uspinlock(&uheap_lock);
					return NULL;
				}
				myVa = (void*)uheapPageAllocBreak;
				breakf=1;
			}
		}

		 int objID = sys_create_shared_object(sharedVarName, size, isWritable, myVa);
		    if (objID < 0)
		    {
		    	//failed allocation
		        if (exactf)
		        blk->free = 1;
		        release_uspinlock(&uheap_lock);
		        return NULL;
		    }

			if (worstfound) {
				newBlk = alloc_block(sizeof(struct uheapPage));
				if (!newBlk) {
				                release_uspinlock(&uheap_lock);
				                return NULL;
				            }
				newBlk->va = TemPblk->va;
				newBlk->size = ActualSize;
				newBlk->free = 0;

				TemPblk->va += ActualSize;
				TemPblk->size -= ActualSize;
				TemPblk->free = 1;
				insert_sorted_page(newBlk);
				//LIST_INSERT_TAIL(&heapBlocks, newBlk);
				myVa = newBlk->va;
			} else if (breakf) {
				blkk = alloc_block(sizeof(struct uheapPage));
				if (!blkk) {
				                release_uspinlock(&uheap_lock);
				                return NULL;
				            }
				blkk->free = 0;
				blkk->size = ActualSize;
				blkk->va = myVa;
				insert_sorted_page(blkk);

				//LIST_INSERT_TAIL(&heapBlocks, blkk);

				uheapPageAllocBreak = ROUNDUP(uheapPageAllocBreak, PAGE_SIZE);
				uheapPageAllocBreak += ActualSize;
			}

			release_uspinlock(&uheap_lock);
			return myVa;

}

//========================================
// [4] SHARE ON ALLOCATED SHARED VARIABLE:
//========================================
void* sget(int32 ownerEnvID, char *sharedVarName)
{
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	uheap_init();
	acquire_uspinlock(&uheap_lock);
		int size = sys_size_of_shared_object(ownerEnvID, sharedVarName);
		if (size < 0){
			release_uspinlock(&uheap_lock);
			return NULL;
		}

		uint32 pageNum = (size + PAGE_SIZE - 1) / PAGE_SIZE;
		uint32 ActualSize = pageNum * PAGE_SIZE;

		void* myVa = NULL;
		bool worstfound = 0;
		bool breakf=0;
		bool exactf=0;
		struct uheapPage *blk=NULL;
		struct uheapPage *TemPblk = NULL;
		struct uheapPage *newBlk = NULL;
		struct uheapPage *blkk = NULL;
		uint32 max = 0;

		LIST_FOREACH(blk, &heapPages) {//exact
			if (blk->free && blk->size == ActualSize) {
				myVa = blk->va;
				blk->free=0;
				exactf=1;
				break;
			}
		}
		if (myVa==NULL){//worst
			LIST_FOREACH(blk, &heapPages) {
				if (blk->free && blk->size > ActualSize && blk->size > max) {
					max = blk->size;
					TemPblk = blk;
					myVa = blk->va;
					worstfound = 1;
				}
		}

		if (!worstfound) {//update break
				uint32 remSize = USER_HEAP_MAX - uheapPageAllocBreak;
				if (remSize < ActualSize) {
					release_uspinlock(&uheap_lock);
					return NULL;
				}
				myVa = (void*)uheapPageAllocBreak;
				breakf=1;
			}
		}

		int objID = sys_get_shared_object(ownerEnvID, sharedVarName, myVa);
			if (objID < 0)
			{//failed
				if (exactf){
					blk->free = 1;
				}

				release_uspinlock(&uheap_lock);
				return NULL;
			}

			if (worstfound) {
				newBlk = alloc_block(sizeof(struct uheapPage));
				if (!newBlk) {
				                release_uspinlock(&uheap_lock);
				                return NULL;
				            }
				newBlk->va = TemPblk->va;
				newBlk->size = ActualSize;
				newBlk->free = 0;

				TemPblk->va += ActualSize;
				TemPblk->size -= ActualSize;
				TemPblk->free = 1;
				insert_sorted_page(newBlk);
				//LIST_INSERT_TAIL(&heapBlocks, newBlk);
				myVa = newBlk->va;
			} else if (breakf) {
				blkk = alloc_block(sizeof(struct uheapPage));
				if (!blkk) {
				                release_uspinlock(&uheap_lock);
				                return NULL;
				            }
				blkk->free = 0;
				blkk->size = ActualSize;
				blkk->va = myVa;
				insert_sorted_page(blkk);

				//LIST_INSERT_TAIL(&heapBlocks, blkk);

				uheapPageAllocBreak = ROUNDUP(uheapPageAllocBreak, PAGE_SIZE);
				uheapPageAllocBreak += ActualSize;
			}

			release_uspinlock(&uheap_lock);
			return myVa;
}


//==================================================================================//
//============================== BONUS FUNCTIONS ===================================//
//==================================================================================//


//=================================
// REALLOC USER SPACE:
//=================================
//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to malloc().
//	A call with new_size = zero is equivalent to free().

//  Hint: you may need to use the sys_move_user_mem(...)
//		which switches to the kernel mode, calls move_user_mem(...)
//		in "kern/mem/chunk_operations.c", then switch back to the user mode here
//	the move_user_mem() function is empty, make sure to implement it.
void *realloc(void *virtual_address, uint32 new_size)
{
	//==============================================================
	//DON'T CHANGE THIS CODE========================================
	uheap_init();
	//==============================================================
	panic("realloc() is not implemented yet...!!");
}


//=================================
// FREE SHARED VARIABLE:
//=================================
//	This function frees the shared variable at the given virtual_address
//	To do this, we need to switch to the kernel, free the pages AND "EMPTY" PAGE TABLES
//	from main memory then switch back to the user again.
//
//	use sys_delete_shared_object(...); which switches to the kernel mode,
//	calls delete_shared_object(...) in "shared_memory_manager.c", then switch back to the user mode here
//	the delete_shared_object() function is empty, make sure to implement it.
void sfree(void* virtual_address)
{
	//TODO: [PROJECT'25.BONUS#5] EXIT #2 - sfree
	//Your code is here
	//Comment the following line
	panic("sfree() is not implemented yet...!!");

	//	1) you should find the ID of the shared variable at the given address
	//	2) you need to call sys_freeSharedObject()
}


//==================================================================================//
//========================== MODIFICATION FUNCTIONS ================================//
//==================================================================================//
