/*
 * fault_handler.c
 *
 *  Created on: Oct 12, 2022
 *      Author: HP
 */

#include "trap.h"
#include <kern/proc/user_environment.h>
#include <kern/cpu/sched.h>
#include <kern/cpu/cpu.h>
#include <kern/disk/pagefile_manager.h>
#include <kern/mem/memory_manager.h>
#include <kern/mem/kheap.h>


//2014 Test Free(): Set it to bypass the PAGE FAULT on an instruction with this length and continue executing the next one
// 0 means don't bypass the PAGE FAULT
uint8 bypassInstrLength = 0;

//===============================
// REPLACEMENT STRATEGIES
//===============================
//2020
void setPageReplacmentAlgorithmLRU(int LRU_TYPE)
{
	assert(LRU_TYPE == PG_REP_LRU_TIME_APPROX || LRU_TYPE == PG_REP_LRU_LISTS_APPROX);
	_PageRepAlgoType = LRU_TYPE ;
}
void setPageReplacmentAlgorithmCLOCK(){_PageRepAlgoType = PG_REP_CLOCK;}
void setPageReplacmentAlgorithmFIFO(){_PageRepAlgoType = PG_REP_FIFO;}
void setPageReplacmentAlgorithmModifiedCLOCK(){_PageRepAlgoType = PG_REP_MODIFIEDCLOCK;}
/*2018*/ void setPageReplacmentAlgorithmDynamicLocal(){_PageRepAlgoType = PG_REP_DYNAMIC_LOCAL;}
/*2021*/ void setPageReplacmentAlgorithmNchanceCLOCK(int PageWSMaxSweeps){_PageRepAlgoType = PG_REP_NchanceCLOCK;  page_WS_max_sweeps = PageWSMaxSweeps;}
/*2024*/ void setFASTNchanceCLOCK(bool fast){ FASTNchanceCLOCK = fast; };
/*2025*/ void setPageReplacmentAlgorithmOPTIMAL(){ _PageRepAlgoType = PG_REP_OPTIMAL; };

//2020
uint32 isPageReplacmentAlgorithmLRU(int LRU_TYPE){return _PageRepAlgoType == LRU_TYPE ? 1 : 0;}
uint32 isPageReplacmentAlgorithmCLOCK(){if(_PageRepAlgoType == PG_REP_CLOCK) return 1; return 0;}
uint32 isPageReplacmentAlgorithmFIFO(){if(_PageRepAlgoType == PG_REP_FIFO) return 1; return 0;}
uint32 isPageReplacmentAlgorithmModifiedCLOCK(){if(_PageRepAlgoType == PG_REP_MODIFIEDCLOCK) return 1; return 0;}
/*2018*/ uint32 isPageReplacmentAlgorithmDynamicLocal(){if(_PageRepAlgoType == PG_REP_DYNAMIC_LOCAL) return 1; return 0;}
/*2021*/ uint32 isPageReplacmentAlgorithmNchanceCLOCK(){if(_PageRepAlgoType == PG_REP_NchanceCLOCK) return 1; return 0;}
/*2021*/ uint32 isPageReplacmentAlgorithmOPTIMAL(){if(_PageRepAlgoType == PG_REP_OPTIMAL) return 1; return 0;}

//===============================
// PAGE BUFFERING
//===============================
void enableModifiedBuffer(uint32 enableIt){_EnableModifiedBuffer = enableIt;}
uint8 isModifiedBufferEnabled(){  return _EnableModifiedBuffer ; }

void enableBuffering(uint32 enableIt){_EnableBuffering = enableIt;}
uint8 isBufferingEnabled(){  return _EnableBuffering ; }

void setModifiedBufferLength(uint32 length) { _ModifiedBufferLength = length;}
uint32 getModifiedBufferLength() { return _ModifiedBufferLength;}

//===============================
// FAULT HANDLERS
//===============================

//==================
// [0] INIT HANDLER:
//==================
void fault_handler_init()
{
	//setPageReplacmentAlgorithmLRU(PG_REP_LRU_TIME_APPROX);
	//setPageReplacmentAlgorithmOPTIMAL();
	setPageReplacmentAlgorithmCLOCK();
	//setPageReplacmentAlgorithmModifiedCLOCK();
	enableBuffering(0);
	enableModifiedBuffer(0) ;
	setModifiedBufferLength(1000);
}
//==================
// [1] MAIN HANDLER:
//==================
/*2022*/
uint32 last_eip = 0;
uint32 before_last_eip = 0;
uint32 last_fault_va = 0;
uint32 before_last_fault_va = 0;
int8 num_repeated_fault  = 0;
extern uint32 sys_calculate_free_frames() ;

struct Env* last_faulted_env = NULL;
void fault_handler(struct Trapframe *tf)
{
	/******************************************************/
	// Read processor's CR2 register to find the faulting address
	uint32 fault_va = rcr2();
	//cprintf("************Faulted VA = %x************\n", fault_va);
	//	print_trapframe(tf);
	/******************************************************/

	//If same fault va for 3 times, then panic
	//UPDATE: 3 FAULTS MUST come from the same environment (or the kernel)
	struct Env* cur_env = get_cpu_proc();
	if (last_fault_va == fault_va && last_faulted_env == cur_env)
	{
		num_repeated_fault++ ;
		if (num_repeated_fault == 3)
		{
			print_trapframe(tf);
			panic("Failed to handle fault! fault @ at va = %x from eip = %x causes va (%x) to be faulted for 3 successive times\n", before_last_fault_va, before_last_eip, fault_va);
		}
	}
	else
	{
		before_last_fault_va = last_fault_va;
		before_last_eip = last_eip;
		num_repeated_fault = 0;
	}
	last_eip = (uint32)tf->tf_eip;
	last_fault_va = fault_va ;
	last_faulted_env = cur_env;
	/******************************************************/
	//2017: Check stack overflow for Kernel
	int userTrap = 0;
	if ((tf->tf_cs & 3) == 3) {
		userTrap = 1;
	}
	if (!userTrap)
	{
		struct cpu* c = mycpu();
		//cprintf("trap from KERNEL\n");
		if (cur_env && fault_va >= (uint32)cur_env->kstack && fault_va < (uint32)cur_env->kstack + PAGE_SIZE)
			panic("User Kernel Stack: overflow exception!");
		else if (fault_va >= (uint32)c->stack && fault_va < (uint32)c->stack + PAGE_SIZE)
			panic("Sched Kernel Stack of CPU #%d: overflow exception!", c - CPUS);
#if USE_KHEAP
		if (fault_va >= KERNEL_HEAP_MAX)
			panic("Kernel: heap overflow exception!");
#endif
	}
	//2017: Check stack underflow for User
	else
	{
		//cprintf("trap from USER\n");
		if (fault_va >= USTACKTOP && fault_va < USER_TOP)
			panic("User: stack underflow exception!");
	}

	//get a pointer to the environment that caused the fault at runtime
	//cprintf("curenv = %x\n", curenv);
	struct Env* faulted_env = cur_env;
	if (faulted_env == NULL)
	{
		cprintf("\nFaulted VA = %x\n", fault_va);
		print_trapframe(tf);
		panic("faulted env == NULL!");
	}
	//check the faulted address, is it a table or not ?
	//If the directory entry of the faulted address is NOT PRESENT then
	if ( (faulted_env->env_page_directory[PDX(fault_va)] & PERM_PRESENT) != PERM_PRESENT)
	{
		faulted_env->tableFaultsCounter ++ ;
		table_fault_handler(faulted_env, fault_va);
	}
	else
	{
		if (userTrap)
		        {
		            /*============================================================================================*/
		            //TODO: [PROJECT'25.GM#3] FAULT HANDLER I - #2 Check for invalid pointers
		            //(e.g. pointing to unmarked user heap page, kernel or wrong access rights),
		            //your code is here
		            int perm=pt_get_page_permissions(faulted_env->env_page_directory, fault_va);
		            if (fault_va >= USER_LIMIT) //pointing to kernel
		            {
		                env_exit();
		            }
		            else if ( (fault_va >= USER_HEAP_START && fault_va < USER_HEAP_MAX)&& !(perm&PERM_UHPAGE))//unmarked user heap page
		            {
		                env_exit();
		            }
		            else if ((perm & PERM_PRESENT) && !(perm & PERM_WRITEABLE)) // Exist with read-only permission
		            {
		                env_exit();
		            }

		            /*============================================================================================*/
		        }

		/*2022: Check if fault due to Access Rights */
		int perms = pt_get_page_permissions(faulted_env->env_page_directory, fault_va);
		if (perms & PERM_PRESENT)
			panic("Page @va=%x is exist! page fault due to violation of ACCESS RIGHTS\n", fault_va) ;
		/*============================================================================================*/


		// we have normal page fault =============================================================
		faulted_env->pageFaultsCounter ++ ;

//				cprintf("[%08s] user PAGE fault va %08x\n", faulted_env->prog_name, fault_va);
//				cprintf("\nPage working set BEFORE fault handler...\n");
//				env_page_ws_print(faulted_env);
		//int ffb = sys_calculate_free_frames();

		if(isBufferingEnabled())
		{
			__page_fault_handler_with_buffering(faulted_env, fault_va);
		}
		else
		{
			page_fault_handler(faulted_env, fault_va);
		}

		//		cprintf("\nPage working set AFTER fault handler...\n");
		//		env_page_ws_print(faulted_env);
		//		int ffa = sys_calculate_free_frames();
		//		cprintf("fault handling @%x: difference in free frames (after - before = %d)\n", fault_va, ffa - ffb);
	}

	/*************************************************************/
	//Refresh the TLB cache
	tlbflush();
	/*************************************************************/
}


//=========================
// [2] TABLE FAULT HANDLER:
//=========================
void table_fault_handler(struct Env * curenv, uint32 fault_va)
{
	//panic("table_fault_handler() is not implemented yet...!!");
	//Check if it's a stack page
	uint32* ptr_table;
#if USE_KHEAP
	{
		ptr_table = create_page_table(curenv->env_page_directory, (uint32)fault_va);
	}
#else
	{
		__static_cpt(curenv->env_page_directory, (uint32)fault_va, &ptr_table);
	}
#endif
}

//=========================
// [3] PAGE FAULT HANDLER:
//=========================
/* Calculate the number of page faults according th the OPTIMAL replacement strategy
 * Given:
 * 	1. Initial Working Set List (that the process started with)
 * 	2. Max Working Set Size
 * 	3. Page References List (contains the stream of referenced VAs till the process finished)
 *
 * 	IMPORTANT: This function SHOULD NOT change any of the given lists
 */
int get_optimal_num_faults(struct WS_List *initWorkingSet, int maxWSSize, struct PageRef_List *pageReferences)
{
    int numFaults = 0;
    struct WS_List myyList;
    LIST_INIT(&myyList);

    struct WorkingSetElement* ptr = NULL;
    LIST_FOREACH(ptr, initWorkingSet){
        struct WorkingSetElement* copy = kmalloc(sizeof(struct WorkingSetElement));
        copy->virtual_address = ptr->virtual_address;
        LIST_INSERT_TAIL(&myyList, copy);
    }

    struct PageRefElement* faulted_page = LIST_FIRST(pageReferences);

    while(faulted_page != NULL){
        bool inWS = 0;

        LIST_FOREACH(ptr, &myyList){
            if(ptr->virtual_address == faulted_page->virtual_address){
                inWS = 1;
                break;
            }
        }


        if(!inWS){
            if(myyList.size < maxWSSize){
                struct WorkingSetElement* new = kmalloc(sizeof(struct WorkingSetElement));
                new->virtual_address = faulted_page->virtual_address;
                LIST_INSERT_TAIL(&myyList, new);
                numFaults++;
            }
            else{
                int maxdis = -1;
                struct WorkingSetElement* furthest = NULL;
                struct WorkingSetElement* PTR;

                LIST_FOREACH(PTR, &myyList){
                    int curdis = 0;
                    struct PageRefElement* next = LIST_NEXT(faulted_page);
                    while(next != NULL && next->virtual_address != PTR->virtual_address){
                        curdis++;
                        next = LIST_NEXT(next);
                    }

                    if(curdis > maxdis){
                        maxdis = curdis;
                        furthest = PTR;
                    }
                }


                    LIST_REMOVE(&myyList, furthest);


                struct WorkingSetElement* new = kmalloc(sizeof(struct WorkingSetElement));
                new->virtual_address = faulted_page->virtual_address;
                LIST_INSERT_TAIL(&myyList, new);
                numFaults++;
            }
        }


        faulted_page = LIST_NEXT(faulted_page);
    }

    return numFaults;
}
struct WS_List myList;
void page_fault_handler(struct Env * faulted_env, uint32 fault_va)
{
#if USE_KHEAP
	if (isPageReplacmentAlgorithmOPTIMAL())
			{
	    static int once=0;


		if(once==0){
			LIST_INIT(&myList);
			struct WorkingSetElement* ptr=NULL;
	    	LIST_FOREACH(ptr, &(faulted_env->page_WS_list)) {
		    struct WorkingSetElement* copy = kmalloc(sizeof(struct WorkingSetElement));
		    copy->virtual_address = ptr->virtual_address;
		    LIST_INSERT_TAIL(&myList, copy);

	   	}
		once=1;
		}
	            bool notInMem=1;
	            uint32* pageTable;
	            int x= get_page_table(faulted_env->env_page_directory, fault_va, &pageTable);
	            struct FrameInfo *framee= get_frame_info(faulted_env->env_page_directory,fault_va,&pageTable);
	                   if(framee!=NULL){
	                       uint32 page_En = pageTable[PTX(fault_va)];
	                       int present = page_En & PERM_PRESENT;
	                                      if (!present) {
	                                          page_En |= PERM_PRESENT;
	                                          pageTable[PTX(fault_va)] = page_En;

	                                      }
	                                    notInMem = 0;
	                   }

                if(notInMem){
                	int perms = PERM_PRESENT | PERM_WRITEABLE | PERM_USER;
                    alloc_page(faulted_env->env_page_directory, fault_va, perms, 0);
        	        int page_exist = pf_read_env_page(faulted_env, (void*)fault_va);
        	        if (page_exist == E_PAGE_NOT_EXIST_IN_PF) {
        	            if (!(((fault_va >= USER_HEAP_START) &&  (fault_va < USER_HEAP_MAX)) || ((fault_va >= USTACKBOTTOM)   && (fault_va < USTACKTOP))) ) {
        	                env_exit();
        	            }
        	        }
        	        notInMem=0;
                }
                fault_va=ROUNDDOWN(fault_va,PAGE_SIZE);
                struct WorkingSetElement* myPtr;
                bool inMyList=0;
                LIST_FOREACH_SAFE(myPtr,&(myList),WorkingSetElement){
                	if(myPtr->virtual_address==fault_va){
                		inMyList=1;
                		break;
                	}
                }
                if(!inMyList){
                	if(LIST_SIZE(&(myList)) == (faulted_env->page_WS_max_size)){
                	LIST_FOREACH_SAFE(myPtr,&(myList),WorkingSetElement){
                     uint32* pt2;
                     get_page_table(faulted_env->env_page_directory,myPtr->virtual_address, &pt2);
                     uint32 en2 = pt2[PTX(myPtr->virtual_address)];
                     en2 &= ~PERM_PRESENT;
                     pt2[PTX(myPtr->virtual_address)] = en2;
                     LIST_REMOVE(&(myList),myPtr);
                	}
             }


                }
                struct PageRefElement* pageEl=kmalloc(sizeof(struct PageRefElement));
                struct WorkingSetElement* newEl= env_page_ws_list_create_element(faulted_env, (uint32)fault_va);
                newEl->virtual_address=fault_va;
                pageEl->virtual_address=fault_va;
                LIST_INSERT_TAIL(&(faulted_env->referenceStreamList), pageEl);
                LIST_INSERT_TAIL(&myList, newEl);
	}

	else
	{
		struct WorkingSetElement *victimWSElement = NULL;
		uint32 wsSize = LIST_SIZE(&(faulted_env->page_WS_list));
		if(wsSize < (faulted_env->page_WS_max_size))
		{


            uint32 va=ROUNDDOWN(fault_va,PAGE_SIZE);

             int perms = PERM_PRESENT | PERM_WRITEABLE | PERM_USER;

            alloc_page(faulted_env->env_page_directory, va, perms, 0);
            int page_exist = pf_read_env_page(faulted_env, (void*)va);
            if (page_exist == E_PAGE_NOT_EXIST_IN_PF) {
                if (!(((va >= USER_HEAP_START) &&  (va < USER_HEAP_MAX)) || ((va >= USTACKBOTTOM)   && (va < USTACKTOP))) ) {
                    env_exit();
                }
            }

            struct WorkingSetElement *lastEl = faulted_env->page_last_WS_element;
            if ((lastEl != NULL) && (lastEl!= LIST_LAST(&(faulted_env->page_WS_list)))) {
                struct WorkingSetElement *ptr = LIST_FIRST(&(faulted_env->page_WS_list));
                while (1) {
                    if(ptr==NULL || ptr ==faulted_env->page_last_WS_element){
                        break;
                    }
                    struct WorkingSetElement *ptrNext = LIST_NEXT(ptr);
                    LIST_REMOVE(&(faulted_env->page_WS_list), ptr);
                    LIST_INSERT_TAIL(&(faulted_env->page_WS_list), ptr);
                    ptr = ptrNext;
                }
            }
            struct WorkingSetElement* wse;
            wse = env_page_ws_list_create_element(faulted_env, (uint32)va);
            LIST_INSERT_TAIL(&(faulted_env->page_WS_list), wse);
            unsigned int wsSize = LIST_SIZE(&(faulted_env->page_WS_list));
            if(wsSize==((faulted_env->page_WS_max_size))){
                faulted_env->page_last_WS_element=LIST_FIRST(&(faulted_env->page_WS_list));
            }

		}

		else
		{
			if (isPageReplacmentAlgorithmCLOCK())
						{
							     struct WorkingSetElement* wse=faulted_env->page_last_WS_element;
								 fault_va = ROUNDDOWN(fault_va, PAGE_SIZE);
					     while(1){

			                         int perm=pt_get_page_permissions(faulted_env->env_page_directory,wse->virtual_address);
			                         int used=perm & PERM_USED ? 1:0;
			                         int modified=perm & PERM_MODIFIED? 1:0;
									if(!(perm & PERM_USED)){

										struct WorkingSetElement* lisNext=LIST_NEXT(wse);
										struct WorkingSetElement* newEl;
										int	perms = PERM_PRESENT | PERM_WRITEABLE   | PERM_USER;
										uint32* ptr_table ;
										struct FrameInfo* ptr_fi = get_frame_info(faulted_env->env_page_directory, wse->virtual_address, &ptr_table);
							              if(perm & PERM_MODIFIED){
							               pf_update_env_page(faulted_env,wse->virtual_address,ptr_fi);
							                }
										 unmap_frame((faulted_env->env_page_directory),ROUNDDOWN((uint32)(wse->virtual_address), PAGE_SIZE));
										 alloc_page(faulted_env->env_page_directory,fault_va,perms,0);
										 int page_exist = pf_read_env_page(faulted_env, (void*)fault_va);
										 if (page_exist == E_PAGE_NOT_EXIST_IN_PF) {
										 if (! (((fault_va >= USER_HEAP_START) &&  (fault_va < USER_HEAP_MAX)) || ((fault_va >= USTACKBOTTOM)   && (fault_va < USTACKTOP))) ) {
											        env_exit();
											     }
											 }
										 newEl = env_page_ws_list_create_element(faulted_env, (uint32)fault_va);
										 if (wse == LIST_FIRST(&(faulted_env->page_WS_list))) {
											 faulted_env->page_last_WS_element = wse->prev_next_info.le_next;
											 LIST_REMOVE(&(faulted_env->page_WS_list),wse);
										     LIST_INSERT_HEAD(&(faulted_env->page_WS_list), newEl);
											            }
										 else if (lisNext == NULL) {
										           	 faulted_env->page_last_WS_element = (struct WorkingSetElement*) LIST_FIRST(&(faulted_env->page_WS_list));
											            LIST_REMOVE(&(faulted_env->page_WS_list),wse);
											            LIST_INSERT_TAIL(&(faulted_env->page_WS_list), newEl);

											            }
										 else {

										     faulted_env->page_last_WS_element = wse->prev_next_info.le_next;
											 LIST_REMOVE(&(faulted_env->page_WS_list),wse);
											 LIST_INSERT_BEFORE(&(faulted_env->page_WS_list), lisNext, newEl);

										 }



													break;
												}
												else{
			                                        pt_set_page_permissions(faulted_env->env_page_directory,wse->virtual_address,0,PERM_USED);
												    if(LIST_NEXT(wse)==NULL)
												    	wse=LIST_FIRST(&(faulted_env->page_WS_list));
												    else wse=LIST_NEXT(wse);

												}

											}
						}

			else if (isPageReplacmentAlgorithmLRU(PG_REP_LRU_TIME_APPROX))
			{
				//TODO: [PROJECT'25.IM#6] FAULT HANDLER II - #2 LRU Aging Replacement
				//Your code is here
				//Comment the following line
				//panic("page_fault_handler().REPLACEMENT is not implemented yet...!!");
				//replacement
					struct WorkingSetElement *elem = NULL;
		    		struct WorkingSetElement *victim = LIST_FIRST(&faulted_env->page_WS_list);
		    		if (victim != NULL)
		    		{
		    		    LIST_FOREACH(elem, &faulted_env->page_WS_list)
		    		    {
		    		        if (elem->time_stamp < victim->time_stamp && victim != NULL)
		    		            victim = elem;
		    		    }
		    		    if (victim != NULL)
		    		    {
		    		        uint32 *ptr = NULL;
		    		        struct FrameInfo *frame = get_frame_info(faulted_env->env_page_directory, victim->virtual_address, &ptr);
		    		        if (frame != NULL)
		    		        {
		    		            int perm = pt_get_page_permissions(faulted_env->env_page_directory, victim->virtual_address);
		    		            if (perm & PERM_MODIFIED)
		    		            {
		    		                int ret = pf_update_env_page(faulted_env, victim->virtual_address, frame);
		    		            }
		    		        }
		    		        env_page_ws_invalidate(faulted_env, victim->virtual_address);
		    		        uint32 va = ROUNDDOWN(fault_va, PAGE_SIZE);

		    		        int perms = pt_get_page_permissions(faulted_env->env_page_directory, va);
		    		        if (perms == 0)
		    		        {
		    		            perms = PERM_PRESENT | PERM_WRITEABLE | PERM_USER;
		    		        }
		    		        struct FrameInfo *p = NULL;
							//alloc_page(faulted_env->env_page_directory, va, perms, 0);

		    		        allocate_frame(&p);
		    		        map_frame(faulted_env->env_page_directory, p, fault_va, PERM_USER | PERM_WRITEABLE);
		    		        int page_exist = pf_read_env_page(faulted_env, (void *)va); // READ the page if exits in the page file
		    		        // CHECK IF EXISTS
		    		        if (page_exist == E_PAGE_NOT_EXIST_IN_PF)
		    		        {
		    		            if (!(((va >= USER_HEAP_START) && (va < USER_HEAP_MAX)) || ((va >= USTACKBOTTOM) && (va < USTACKTOP))))
		    		            {
		    		                env_exit();
		    		            }
		    		        }
		    		        struct WorkingSetElement *newWS = env_page_ws_list_create_element(faulted_env, va);
		    		        LIST_INSERT_TAIL(&faulted_env->page_WS_list, newWS);
		    		        unsigned int wsSize = LIST_SIZE(&(faulted_env->page_WS_list));
		    		        if (wsSize == ((faulted_env->page_WS_max_size)))
		    		        {
		    		            faulted_env->page_last_WS_element = LIST_FIRST(&(faulted_env->page_WS_list));
		    		        }
		    		    }
		    		}


				return;
				}


			else if (isPageReplacmentAlgorithmModifiedCLOCK())
			{



				//TODO: [PROJECT'25.IM#6] FAULT HANDLER II - #3 Modified Clock Replacement
				//Your code is here
				//Comment the following line
				//panic("page_fault_handler().REPLACEMENT is not implemented yet...!!");

					struct WorkingSetElement* victim=NULL;
					struct WorkingSetElement* elem=faulted_env->page_last_WS_element;
					while (victim==NULL ){
						for (int i=0;i<faulted_env->page_WS_max_size;i++)
						{
							int perm=pt_get_page_permissions(faulted_env->env_page_directory,elem->virtual_address);
							if (!(perm&PERM_MODIFIED) && !(perm&PERM_USED)){//modified=0,used=0 (best)
								victim=elem;
								break;
							}
							elem=elem->prev_next_info.le_next;
							if (elem==NULL)
							elem=LIST_FIRST(&faulted_env->page_WS_list);

						}
					if (victim==NULL){
						for (int i=0;i<faulted_env->page_WS_max_size;i++)
						{
							int perm=pt_get_page_permissions(faulted_env->env_page_directory,elem->virtual_address);
							if (!(perm&PERM_USED)){//used=0
								victim=elem;
								break;
							}
							else{
								pt_set_page_permissions(faulted_env->env_page_directory, elem->virtual_address, 0, PERM_USED);
							}
							elem=elem->prev_next_info.le_next;
							if (elem==NULL)
							    elem=LIST_FIRST(&faulted_env->page_WS_list);

						}


					}

					}
					if (victim!=NULL){
						uint32 *ptr=NULL;
						struct FrameInfo* frame = get_frame_info(faulted_env->env_page_directory, victim->virtual_address, &ptr);
						if (frame != NULL) {
							int perm = pt_get_page_permissions(faulted_env->env_page_directory, victim->virtual_address);
							if (perm & PERM_MODIFIED) {
								int ret= pf_update_env_page(faulted_env, victim->virtual_address, frame);
							}
						}

						uint32 va=ROUNDDOWN(fault_va,PAGE_SIZE);
						int perms = pt_get_page_permissions(faulted_env->env_page_directory, va);
						 struct WorkingSetElement* nExtt=LIST_NEXT(victim);
						//unmap_frame(faulted_env->env_page_directory,ROUNDDOWN((uint32)victim->virtual_address,PAGE_SIZE));
						env_page_ws_invalidate(faulted_env, victim->virtual_address);
						if (perms == 0) {
													perms = PERM_PRESENT | PERM_WRITEABLE | PERM_USER;
												}
						struct FrameInfo *p = NULL;
						allocate_frame(&p);
						map_frame(faulted_env->env_page_directory, p, fault_va, PERM_USER | PERM_WRITEABLE);
					    //alloc_page(faulted_env->env_page_directory, va, perms, 0);
						int page_exist = pf_read_env_page(faulted_env, (void*)va); //READ the page if exits in the page file
						//CHECK IF EXISTS
						if (page_exist == E_PAGE_NOT_EXIST_IN_PF) {
							if (! (((va >= USER_HEAP_START) &&  (va < USER_HEAP_MAX)) || ((va >= USTACKBOTTOM)   && (va < USTACKTOP))) ) {
								env_exit();
							}
						}
						 struct WorkingSetElement *newWS=env_page_ws_list_create_element(faulted_env,va);
						 pt_set_page_permissions(faulted_env->env_page_directory, newWS->virtual_address, PERM_USED, 0);  // set USED
						 pt_set_page_permissions(faulted_env->env_page_directory, newWS->virtual_address, 0, PERM_MODIFIED);
						 if (nExtt==NULL){
							 faulted_env->page_last_WS_element=LIST_FIRST(&faulted_env->page_WS_list);

							 LIST_INSERT_TAIL(&faulted_env->page_WS_list,newWS);

						 }
						 else if (LIST_FIRST(&faulted_env->page_WS_list)==victim){
							 faulted_env->page_last_WS_element=nExtt;

							 LIST_INSERT_HEAD(&faulted_env->page_WS_list,newWS);
						 }
						 else{
							 faulted_env->page_last_WS_element=nExtt;

							 LIST_INSERT_BEFORE(&faulted_env->page_WS_list,nExtt,newWS);

						 }
					}
				}

			}

		}

#endif
}

void __page_fault_handler_with_buffering(struct Env * curenv, uint32 fault_va)
{
	panic("this function is not required...!!");
}



