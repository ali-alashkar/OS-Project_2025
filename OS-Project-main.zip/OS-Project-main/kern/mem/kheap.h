#ifndef FOS_KERN_KHEAPH
#define FOS_KERN_KHEAPH

#ifndef FOS_KERNEL
#endif

#include <inc/types.h>
#include <inc/queue.h>
#include <inc/memlayout.h>



//Values for user heap placement strategy
#define KHP_PLACE_CONTALLOC 0x0
#define KHP_PLACE_FIRSTFIT     0x1
#define KHP_PLACE_BESTFIT     0x2
#define KHP_PLACE_NEXTFIT     0x3
#define KHP_PLACE_WORSTFIT     0x4
#define KHP_PLACE_CUSTOMFIT 0x5
#define MXSIZE ((KERNEL_HEAP_MAX-KERNEL_HEAP_START)/PAGE_SIZE)
#define MAX_BLOCKS 1024
//TODO: [PROJECT'25.GM#2] KERNEL HEAP - #0 Page Alloc Limits [GIVEN]
uint32 kheapPageAllocStart ;
uint32 kheapPageAllocBreak ;
uint32 kheapPlacementStrategy;
//Replaced by setter & getter function
static inline void set_kheap_strategy(uint32 strategy){kheapPlacementStrategy = strategy;}
static inline uint32 get_kheap_strategy(){return kheapPlacementStrategy ;}
LIST_HEAD(heapBlocks, kHeapBlock);
struct kHeapBlock{
    LIST_ENTRY(kHeapBlock) prev_next_info;
    uint32 size;
    bool free;
    void* va;
};
static struct kHeapBlock heapBlockArray[MAX_BLOCKS];
static int heapBlockCount = 0;
struct FreeList {
    int size;
    struct kHeapBlock *head;   // list of blocks of this exact size
};

//**
void kheap_init();
void return_page(void* va);
void* kmalloc(unsigned int size);
void kfree(void* virtual_address);
void* krealloc(void* virtual_address, unsigned int new_size);
void* fast_kmalloc(unsigned int size);

unsigned int kheap_virtual_address(unsigned int physical_address);
unsigned int kheap_physical_address(unsigned int virtual_address);

int numOfKheapVACalls ;
uint32 mxsize;
#endif // FOS_KERN_KHEAPH
