#include "kheap.h"
//#include <kern/mem/boot_time_memory.h>
#include <inc/memlayout.h>
#include <inc/dynamic_allocator.h>
#include <kern/conc/sleeplock.h>
#include <kern/conc/kspinlock.h>
#include <kern/proc/user_environment.h>
#include <kern/mem/memory_manager.h>
#include <inc/queue.h>

//==================================================================================//
//============================== GIVEN FUNCTIONS ===================================//
//==================================================================================//

//==============================================
// [1] INITIALIZE KERNEL HEAP:
//==============================================
//TODO: [PROJECT'25.GM#2] KERNEL HEAP - #0 kheap_init [GIVEN]
//Remember to initialize locks (if any)

struct heapBlocks heapBlocks;
struct kspinlock kheap_lock;
struct FreeList *free_table;// map: sizlist


LIST_HEAD(KBlockElement_List,kHeapBlock);
struct KBlockElement_List KHBlockLists[(KERNEL_HEAP_MAX-KERNEL_HEAP_START)/PAGE_SIZE] ;
LIST_HEAD(maxBlocks, kHeapBlock);
struct maxBlocks maxBlocks;
void kheap_init()
{
    //==================================================================================
    //DON'T CHANGE THESE LINES==========================================================
    //==================================================================================
    {
        initialize_dynamic_allocator(KERNEL_HEAP_START, KERNEL_HEAP_START + DYN_ALLOC_MAX_SIZE);
        set_kheap_strategy(KHP_PLACE_CUSTOMFIT);
        kheapPageAllocStart = dynAllocEnd + PAGE_SIZE;
        kheapPageAllocBreak = kheapPageAllocStart;
    }
    LIST_INIT(&heapBlocks);
    LIST_INIT(&maxBlocks);
    for(int i = 0; i < (KERNEL_HEAP_MAX-KERNEL_HEAP_START)/PAGE_SIZE; i++) {
        LIST_INIT(&KHBlockLists[i]);
      }


    init_kspinlock(&kheap_lock, "kheap");

    //==================================================================================
    //==================================================================================
}

//==============================================
// [2] GET A PAGE FROM THE KERNEL FOR DA:
//==============================================
int get_page(void* va)
{
	int ret = alloc_page(ptr_page_directory, ROUNDDOWN((uint32)va, PAGE_SIZE), PERM_WRITEABLE, 1);
	if (ret < 0)
		panic("get_page() in kern: failed to allocate page from the kernel");
	return 0;
}

//==============================================
// [3] RETURN A PAGE FROM THE DA TO KERNEL:
//==============================================
void return_page(void* va)
{
	unmap_frame(ptr_page_directory, ROUNDDOWN((uint32)va, PAGE_SIZE));
}

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//
//===================================
// [1] ALLOCATE SPACE IN KERNEL HEAP:
//===================================

void insert_sorted_block(struct kHeapBlock *blk) {
    struct kHeapBlock *b;
    LIST_FOREACH(b, &heapBlocks) {
        if ((uint32)blk->va < (uint32)b->va) {
            LIST_INSERT_BEFORE(&heapBlocks,b, blk);
            return;
        }
    }
    LIST_INSERT_TAIL(&heapBlocks, blk);
}


void* kmalloc(unsigned int size)
{

	acquire_kspinlock(&kheap_lock);

	if (size <= 2048) {
		release_kspinlock(&kheap_lock);
		return alloc_block(size);
	}

	uint32 pageNum = (size + PAGE_SIZE - 1) / PAGE_SIZE;
	uint32 ActualSize = pageNum * PAGE_SIZE;
	void* myVa = NULL;
	bool worstfound = 0;
	bool breakf=0;
	bool exactf=0;
	struct kHeapBlock *blk=NULL;
	struct kHeapBlock *TemPblk = NULL;
	struct kHeapBlock *newBlk = NULL;
	struct kHeapBlock *blkk = NULL;
	uint32 max = 0;

	LIST_FOREACH(blk, &heapBlocks) {//exact
		if (blk->free && blk->size == ActualSize) {
			myVa = blk->va;
			blk->free=0;
			exactf=1;
			break;
		}
	}
	if (myVa==NULL){//worst
	LIST_FOREACH(blk, &heapBlocks) {
		if (blk->free && blk->size > ActualSize && blk->size > max) {
			max = blk->size;
			TemPblk = blk;
			myVa = blk->va;
			worstfound = 1;
		}
	}
	if (!worstfound ) {//update break
			uint32 remSize = KERNEL_HEAP_MAX - kheapPageAllocBreak;
			if (remSize < ActualSize) {
				release_kspinlock(&kheap_lock);
				return NULL;
			}
			myVa = (void*)kheapPageAllocBreak;
			breakf=1;
		}
	}

	void* temp = myVa;

	for (int i = 0; i < pageNum; i++) {
		struct FrameInfo* ptr_FrameInfo=NULL;
		if (allocate_frame(&ptr_FrameInfo) != 0) {
			 uint32 temp2=(uint32)myVa;
			for (int j = 0; j < i; j++) {
				void* t = (void*)((uint32)myVa + j * PAGE_SIZE);
				unmap_frame(ptr_page_directory, (uint32)t);
			}
			//release_kspinlock(&kheap_lock);
			//return NULL;
			if (exactf){
				blk->free=1;
			}
		}

		if (map_frame(ptr_page_directory, ptr_FrameInfo, (uint32)temp, PERM_WRITEABLE | PERM_PRESENT) != 0) {
			uint32 temp2=(uint32)myVa;
			for (int j = 0; j <= i; j++) {
				void* t = (void*)((uint32)myVa + j * PAGE_SIZE);
				unmap_frame(ptr_page_directory, (uint32)t);
			}
			if (exactf) {
			                blk->free = 1;
			            }
			release_kspinlock(&kheap_lock);
			return NULL;
		}

		temp = (void*)((uint32)temp + PAGE_SIZE);
	}

	if (worstfound ) {
		newBlk = alloc_block(sizeof(struct kHeapBlock));
		if (!newBlk) {
		                release_kspinlock(&kheap_lock);
		                return NULL;
		            }
		newBlk->va = TemPblk->va;
		newBlk->size = ActualSize;
		newBlk->free = 0;

		TemPblk->va += ActualSize;
		TemPblk->size -= ActualSize;
		TemPblk->free = 1;
		insert_sorted_block(newBlk);
		//LIST_INSERT_TAIL(&heapBlocks, newBlk);
		myVa = newBlk->va;
	} else if (breakf) {
		blkk = alloc_block(sizeof(struct kHeapBlock));
		if (!blkk) {
		                release_kspinlock(&kheap_lock);
		                return NULL;
		            }
		blkk->free = 0;
		blkk->size = ActualSize;
		blkk->va = myVa;
		insert_sorted_block(blkk);

		//LIST_INSERT_TAIL(&heapBlocks, blkk);

		kheapPageAllocBreak = ROUNDUP(kheapPageAllocBreak, PAGE_SIZE);
		kheapPageAllocBreak += ActualSize;
	}

	release_kspinlock(&kheap_lock);
	return myVa;
}
//=================================
// [2] FREE SPACE FROM KERNEL HEAP:
//=================================
void kfree(void* virtual_address)
{
	//TODO: [PROJECT'25.GM#2] KERNEL HEAP - #2 kfree
	//Your code is here
	//Comment the following line
	//panic("kfree() is not implemented yet...!!");
	virtual_address=(void*)ROUNDDOWN((uint32)virtual_address, PAGE_SIZE);

	acquire_kspinlock(&kheap_lock);
    if(virtual_address==NULL || (uint32)virtual_address>KERNEL_HEAP_MAX ||(uint32)virtual_address<KERNEL_HEAP_START){
    	release_kspinlock(&kheap_lock);

    	return;
    }
    struct kHeapBlock* blk=NULL;
    LIST_FOREACH(blk, &heapBlocks) {
        if (virtual_address==blk->va){
            break;
        }
    }
    if (blk==NULL){
    	release_kspinlock(&kheap_lock);

        return;
    }

    uint32 pagesToFree=(blk->size + PAGE_SIZE - 1) / PAGE_SIZE;
    void * temp=virtual_address;
    for (int i=0;i<pagesToFree;i++){
                uint32 *ptr=NULL;
                if (get_frame_info(ptr_page_directory,(uint32)temp,&ptr)!=0){
                 return_page(temp);
                }
                else{
                	return ;
                }
                temp = (void*)((uint32)temp + PAGE_SIZE);
            }
    blk->free=1;
    struct kHeapBlock* prev = blk->prev_next_info.le_prev;
        struct kHeapBlock* next = blk->prev_next_info.le_next;
        struct kHeapBlock* tmp=blk;
        //merge
        if (next!=NULL &&next->free){
            blk->size+=next->size;
            LIST_REMOVE(&heapBlocks,next);
        }
        if (prev!=NULL &&prev->free){
            prev->size+=blk->size;
            LIST_REMOVE(&heapBlocks,blk);
            tmp=prev;
        }

        //allocbreak
        if ((uint32)(tmp->va+tmp->size)==kheapPageAllocBreak){
            kheapPageAllocBreak-=tmp->size;
            LIST_REMOVE(&heapBlocks,tmp);
        }

	release_kspinlock(&kheap_lock);

	return;
}

//=================================
// [3] FIND VA OF GIVEN PA:
//=================================
unsigned int kheap_virtual_address(unsigned int physical_address)
{
    if (physical_address ==0) return 0;
    /* If you have a function that takes frame number:
       struct FrameInfo *fi = get_frame_info(frame_no);
       Otherwise, if to_frame_info expects physical base:
       struct FrameInfo *fi = to_frame_info(pa_base);
    */
    struct FrameInfo *fi = to_frame_info((physical_address & 0xFFFFF000));
    if (fi == NULL) return 0;

    unsigned int page_va = fi->virtual_address   & 0xFFFFF000;
    if(page_va <KERNEL_HEAP_START || page_va >=KERNEL_HEAP_MAX)
        return 0;
    return (page_va) | (physical_address & 0xFFF);
}

//=================================
// [4] FIND PA OF GIVEN VA:
//=================================
unsigned int kheap_physical_address(unsigned int virtual_address)
{
    //TODO: [PROJECT'25.GM#2] KERNEL HEAP - #4 kheap_physical_address
    //Your code is here
    uint32 pageTable_En = ptr_page_directory[PDX(virtual_address)];
        if ((pageTable_En & 0x1) == 0) {
            return 0;
        }
        uint32* pageTable ;
        get_page_table(ptr_page_directory,virtual_address,&pageTable);
        uint32 page_En = pageTable[PTX(virtual_address)];
        if ((page_En & 0x1 )==0) {
            return 0;
        }
        uint32 temp2 = page_En >> 12;
        uint32 pagePn = temp2 & 0xFFFFF;
        uint32 physicalAdd = pagePn * PAGE_SIZE + PGOFF(virtual_address);
        return physicalAdd;

    /*EFFICIENT IMPLEMENTATION ~O(1) IS REQUIRED */
}
//=================================================================================//
//============================== BONUS FUNCTION ===================================//
//=================================================================================//
// krealloc():

//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to kmalloc().
//	A call with new_size = zero is equivalent to kfree().

extern __inline__ uint32 get_block_size(void *va);

void *krealloc(void *virtual_address, uint32 new_size)
{
	//TODO: [PROJECT'25.BONUS#2] KERNEL REALLOC - krealloc
	//Your code is here
	//Comment the following line
	//panic("krealloc() is not implemented yet...!!");
	return NULL;
}


uint32 mxblockSize=0;
void* fast_kmalloc(unsigned int size)
{



	acquire_kspinlock(&kheap_lock);

	if (size <= 2048) {
		release_kspinlock(&kheap_lock);
		return alloc_block(size);
	}

	uint32 pageNum = (size + PAGE_SIZE - 1) / PAGE_SIZE;
	uint32 ActualSize = pageNum * PAGE_SIZE;
	void* myVa = NULL;
	bool worstfound = 0;
	bool breakf=0;
	bool exactf=0;
	struct kHeapBlock *blk=NULL;
	struct kHeapBlock *TemPblk = NULL;
	struct kHeapBlock *newBlk = NULL;
	struct kHeapBlock *blkk = NULL;
	uint32 max = 0;

	//exactfit
	struct KHeapBlock *exactblk = LIST_FIRST(&KHBlockLists[ActualSize]);
	if (exactblk!=NULL){
		myVa = exactblk->va;
		exactblk->free=0;
		exactf=1;
	}

	else{
		//worstfit
		struct KHeapBlock *worstblk = LIST_LAST(&KHBlockLists[mxblockSize]);

		if (worstblk!=NULL && worstblk->size>ActualSize){
			max = worstblk->size;
			TemPblk = worstblk;
			myVa = worstblk->va;
			worstfound = 1;
		}
		else{//updatebreak
			uint32 remSize = KERNEL_HEAP_MAX - kheapPageAllocBreak;
						if (remSize < ActualSize) {
							release_kspinlock(&kheap_lock);
							return NULL;
						}
						myVa = (void*)kheapPageAllocBreak;
						breakf=1;
		}



	}
	void* temp = myVa;

	for (int i = 0; i < pageNum; i++) {
		struct FrameInfo* ptr_FrameInfo=NULL;
		if (allocate_frame(&ptr_FrameInfo) != 0) {
			 uint32 temp2=(uint32)myVa;
			for (int j = 0; j < i; j++) {
				void* t = (void*)((uint32)myVa + j * PAGE_SIZE);
				unmap_frame(ptr_page_directory, (uint32)t);
			}
			//release_kspinlock(&kheap_lock);
			//return NULL;
			if (exactf){
				blk->free=1;
			}
		}

		if (map_frame(ptr_page_directory, ptr_FrameInfo, (uint32)temp, PERM_WRITEABLE | PERM_PRESENT) != 0) {
			uint32 temp2=(uint32)myVa;
			for (int j = 0; j <= i; j++) {
				void* t = (void*)((uint32)myVa + j * PAGE_SIZE);
				unmap_frame(ptr_page_directory, (uint32)t);
			}
			if (exactf) {
			                blk->free = 1;
			                LIST_REMOVE(&KHBlockLists[ActualSize],exactblk);
			            }
			release_kspinlock(&kheap_lock);
			return NULL;
		}

		temp = (void*)((uint32)temp + PAGE_SIZE);
	}

	if (worstfound ) {
		LIST_REMOVE(&KHBlockLists[mxblockSize],worstblk);
		newBlk = alloc_block(sizeof(struct kHeapBlock));
		if (!newBlk) {
		                release_kspinlock(&kheap_lock);
		                return NULL;
		            }
		newBlk->va = TemPblk->va;
		newBlk->size = ActualSize;
		newBlk->free = 0;

		TemPblk->va += ActualSize;
		TemPblk->size -= ActualSize;
		TemPblk->free = 1;
		insert_sorted_block(newBlk);
		//LIST_INSERT_TAIL(&heapBlocks, newBlk);
		myVa = newBlk->va;
	} else if (breakf) {
		blkk = alloc_block(sizeof(struct kHeapBlock));
		if (!blkk) {
		                release_kspinlock(&kheap_lock);
		                return NULL;
		            }
		blkk->free = 0;
		blkk->size = ActualSize;
		blkk->va = myVa;
		insert_sorted_block(blkk);

		//LIST_INSERT_TAIL(&heapBlocks, blkk);

		kheapPageAllocBreak = ROUNDUP(kheapPageAllocBreak, PAGE_SIZE);
		kheapPageAllocBreak += ActualSize;
	}

	release_kspinlock(&kheap_lock);
	return myVa;
}
